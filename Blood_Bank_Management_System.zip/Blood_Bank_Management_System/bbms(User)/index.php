<?php
include('db.php');
session_start();
?>
<html>
<head>
      <title>Blood Bank Home</title>
      <link rel="stylesheet" type="text/css" href="css/style.css">
      </style>
</head>
<body>
   <div class="header">
     <div class="logo"><h2>MD Blood Bank</h2> </div>
       <div class="nav">
         <div id="a"><a href="index.php">Home</a></div>
         <div id="b"><a href="about.php">About</a></div>
         <div id="c"><a href="contact.php">Contact Us</a></div> 
      </div>
</div>
     <div id="image">
         <center><img src="img/i1.jpg" width="100%" height="700px" ></center>
     </div>    
  <div class="container">
      <br>
      <h2 align="center" style="color:crimson">Doctor's Information</h2>
      
    <center>
      <table border="1px" style= "width: 800px; line-height: 50px;">
         <tr>
           <th><b>Doctor_Name</b></th>
           <th><b>Mobile_No</b></th>
           <th><b>Address</b></th>
           <th><b>Specialization</b></th>
         </tr>
         <?php 
         $q=$db->query("SELECT * FROM doctor_info");
             while($r1=$q->fetch(PDO::FETCH_OBJ))
            {
          ?>
          <tr>       
          <td><center><?= $r1->Doctor_Name; ?></center></td> 
          <td><center><?= $r1->Mobile_No; ?></center></td> 
          <td><center><?= $r1->Address; ?></center></td> 
          <td><center><?= $r1->Specialization; ?></center> </td> 
          </tr>
       <?php 
      }
      ?>
    </table>
  </center>
  </div>
      <div class="footer"><h2 align="center">www.ppsubloodbank.in</h2></div>
</body>
</html>