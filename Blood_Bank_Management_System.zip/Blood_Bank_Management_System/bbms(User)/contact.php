<!DOCTYPE html>
<html>
<head>
      <title>Blood Bank Home</title>
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <style type ="text/css">
         #address{width :50% ;height:300px ; float: left;}
         #map{width :50%; height:300px; float: left;}
      </style>
</head>
<body>
  <div class="header">
     <div class="logo"><h2>MD Blood Bank<h2></div>
       <div class="nav">
         <div id="a"><a href="index.php">Home</a></div>
         <div id="b"><a href="about.php">About</a></div>
         <div id="c"><a href="contact.php">Contact Us</a></div>
      </div>
  </div>  
  <div id="image">
         <center><img src="img/i1.jpg" width="100%" height="700px"></center>
     </div>  
    <div class="container">
      <br>
     <div id="address">
      <h3> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Contact Blood Bank</h2><br>
       <p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>Address:</b> &nbsp;Dr. CV Raman Marg, Yashkamal Society,<br>
       &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Vasna, Ahmedabad, Gujarat 380007</p>
       <p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b>  Mobile no:</b> &nbsp; +079 2660 0101</p>
       <p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <b> Email:</b> &nbsp; &nbsp; &nbsp;mdbloodbank@gmail.com</p><br>
     </div>
     <div id="map">
         <p>
           <iframe src="https://www.google.com/maps/d/embed?mid=1m9O3tdfATOzrMZxKsXK5QdKGDGPAxBs3"
             width="500" height="320"></iframe>
         </p>   
     </div>
    </div>
      <br><br><br><br>
      <div class="footer"><h2 align="center">www.ppsubloodbank.in</h2></div>
</body>
</html>