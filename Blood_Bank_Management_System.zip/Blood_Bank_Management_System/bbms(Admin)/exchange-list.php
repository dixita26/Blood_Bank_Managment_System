<?php
include('connection.php');
session_start();
?>
<html>
<head>
<title>Exchange-List</title>
<link rel="stylesheet" type="text/css" href="css/s1.css">
<style type="text/css">
    td{
        width:200px;
        height:40px;
    }
</style>
</head>
<body>
<div class="header">
       <div class="logo"><h2>MD Blood Bank<h2></div>
       <div class="nav">
         <div id="a"><a href="admin-home.php">Home</a></div>
         <div id="b"><a href="donor-reg.php">Donor Registration</a></div>
         <div id="c"><a href="donor-list.php">Donor List</a></div>
         <div id="e"><a href="stoke-blood-list.php">Stoke Blood List</a></div>
         <div id="f"><a href="out-stoke-list.php">Out Stoke Blood List</a></div>
         <div id="g"><a href="exchange-Blood-reg.php">Exchange Blood Registration</a></div>
         <div id="h"><a href="exchange-list.php">Exchange Blood List</a></div>
      </div>
   </div>
<div id="full">
    <div id="inner_full">
       <div id="header" align="center"><h2><a href="admin-home.php" style="text-decoration:none; color:whitesmoke;"></a></h2></div>
       <div id="body">
           <?php
           $un=$_SESSION['un'];
           if(!$un)
           {
               header("Location:index.php");
           }
           ?>
            <h2 align="center">Exchange Blood List</h2>
            <center><div id="form">
                <table>
                    <tr>
                        <td><center><b><font color="whitesmoke">Name</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Father's Name</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Address</font></b></center></td>
                        <td><center><b><font color="whitesmoke">City</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Age</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Email-ID</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Mobile No</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Blood Group</font></b></center></td>
                        <td><center><b><font color="whitesmoke">Exchange Blood Group</font></b></center></td>
                    </tr>
                    <?php 
                    $q=$db->query("SELECT * FROM exchange_b");
                    while($r1=$q->fetch(PDO::FETCH_OBJ))
                    {
                        ?>
                    <tr>
                        <td><center><?= $r1->name; ?></center></td>
                        <td><center><?= $r1->fname; ?></center></td>
                        <td><center><?= $r1->address; ?></center></td>
                        <td><center><?= $r1->city; ?></center></td>
                        <td><center><?= $r1->age; ?></center></td>
                        <td><center><?= $r1->email; ?></center></td>
                        <td><center><?= $r1->mno; ?></center></td>
                        <td><center><?= $r1->bgroup; ?></center></td>
                        <td><center><?= $r1->exbgroup; ?></center></td>
                    
                    </tr>
                    
                    <?php
                    }   
                    ?>
                </table>
            </div></center>
       </div>
       <div id="footer"><p align="center"><a href="logout.php"><font color="whitesmoke"><h3 align="center">Logout</h3></a></p></div>
           
</body>
</html>