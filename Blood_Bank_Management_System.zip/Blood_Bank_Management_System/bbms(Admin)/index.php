<?php
include('connection.php');
session_start();
?>
<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" type="text/css" href="css/s1.css">
</head>
<body>
<div class="header">
       <div class="logo"><h2>MD Blood Bank<h2></div>
       <div class="nav">
         <div id="a"><a href="admin-home.php">Home</a></div>
         <div id="b"><a href="donor-reg.php">Donor Registration</a></div>
         <div id="c"><a href="donor-list.php">Donor List</a></div>
         <div id="e"><a href="stoke-blood-list.php">Stoke Blood List</a></div>
         <div id="f"><a href="out-stoke-list.php">Out Stoke Blood List</a></div>
         <div id="g"><a href="exchange-Blood-reg.php">Exchange Blood Registration</a></div>
         <div id="h"><a href="exchange-list.php">Exchange Blood List</a></div>
      </div>
   </div>
<div id="full">
    <div id="inner_full">
       <div id="body">
           <br><br><br><br><br>
           <form action="" method="post">
           <table align="center">
                <tr>
                   <td width="200px" height="70px"><b>Enter Username</b></td>
                   <td width="100px" height="70px"><input type="text" name="un" placeholder="Enter Username" 
                   style="width:180px; height:30px; border-radius:10px;"></td>
                </tr>
                <tr>
                   <td width="200px" height="70px"><b>Enter Password</b></td>
                   <td width="100px" height="70px"><input type="text" name="ps" placeholder="Enter Password"
                   style="width:180px; height:30px; border-radius:10px;"></td>
                </tr>
                <tr>
                    <td><input type="submit" name="sub" value="Login" style="width:70px; height:30px; border-radius:10px;"></td>
                </tr>
           </table>
           </form>
           <?php
           if(isset($_POST['sub']))
           {
               $un=$_POST['un'];
               $ps=$_POST['ps'];
               $q=$db->prepare("SELECT * from admin where uname='$un' and pass='$ps'");
               $q->execute();
               $res=$q->fetchAll(PDO::FETCH_OBJ);
               if($res)
               {
                   $_SESSION['un']=$un;
                   header("Location:admin-home.php");
               }
               else
               {
                   echo"<script>alert('Wrong User');</script>";
               }
           }
           ?>
       </div>
       <div id="footer"><p align="center"><a href="logout.php"><font color="whitesmoke"><h3 align="center">Logout</h3></a></p></div>
</body>
</html>